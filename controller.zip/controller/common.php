<?php
    if(isset($_POST['subject']) && !empty($_POST['subject']) && 
    isset($_POST['message']) && !empty($_POST['message'])){
        
        $destino = "diegovelasco96@gmail.com";
        $desde = "From: ". "Kids party center";
        $asunto = $_POST['subject'];
        $mensaje = $_POST['message'];

        mail($destino, $asunto, $mensaje, $desde);

        echo "Correo enviado....";
    }else{
        echo "Problemas al enviar...";
    }

?>